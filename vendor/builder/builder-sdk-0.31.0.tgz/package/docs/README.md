# Builder SDK — widgets, kits and data files

`@builder/sdk` is how a site or a third party extends the builder. A new widget is **one file** that no part of the editor has to know about: the widget panel, the Content, Style and Advanced tabs, validation, publishing and the site render all read what the widget declares.

- A complete example package: [`examples/widget-timeline`](../../../examples/widget-timeline/src/index.tsx), with [its tests](../../../examples/widget-timeline/test/timeline.test.mts).
- The demo site adds it with one line (`examples/demo-site/builder.config.ts`) and shows it at `/timeline/`.

## 1. A widget in one file

```tsx
import { defineWidget, f } from "@builder/sdk";

export const Timeline = defineWidget({
  type: "acme/Timeline",            // id: "namespace/PascalName"
  version: 2,                       // bump when stored props change (with a migration)
  label: "Timeline",                // name in the widget panel
  category: "basic",                // panel group
  icon: "list",                     // panel icon (the builder's icon set)
  description: "Numbered steps",    // one line in the panel
  keywords: ["steps", "process"],   // widget search
  fields: {                         // content controls; props are typed from them
    title: f.text({ label: "Title", maxLength: 80, inline: true }),
    layout: f.select({ label: "Layout", options: ["vertical", "horizontal"] as const }),
    steps: f.list({ label: "Steps", item: { title: f.text({ label: "Step", required: true }) }, itemLabel: "title", max: 12 }),
  },
  defaults: { title: "How it works", layout: "vertical", steps: [{ title: "One" }, { title: "Two" }] },
  styles: ["spaceTop", "spaceBottom", "background", "textColor", "align"], // Style tab, per device
  parts: { number: { label: "Step number", selector: ".acme-tl-n", styles: ["background", "textColor"] } },
  validate: (p) => (p.steps.length < 2 ? ["A timeline needs at least two steps"] : []),
  migrations: { 1: (p) => ({ ...p, steps: (p.steps as { heading: string }[]).map((s) => ({ title: s.heading })) }) },
  render: ({ title, layout, steps }) => (/* React: plain HTML and CSS where possible */ <section>…</section>),
});
```

The site adds it with one line in `builder.config.ts`:

```ts
components: [...baseComponents, ...proComponents, Timeline]
```

## 2. Reference

| Key | Required | What it does |
|---|---|---|
| `type` | yes | The id. A `namespace/PascalName` that never changes; stored pages refer to it. Use your own namespace. `base/`, `pro/` and `site/` belong to the builder. |
| `version` | yes | A positive integer. Raise it whenever stored props change meaning, and add a migration. |
| `label`, `category` | yes | Name and group in the widget panel. |
| `icon`, `description`, `keywords` | no | Panel icon, one line of description, search words. |
| `fields` | yes | Content controls. [Field kinds](#field-kinds) are below. |
| `defaults` | yes | Props of a new widget. Checked against the fields. |
| `styles` | no | **Responsive controls**: Style-tab keys, each with Desktop, Tablet and Mobile values (and more when the site adds breakpoints). See `STYLE_KEYS` in `@builder/core`. |
| `parts` | no | Inner elements with their own Style controls, Normal / Hover / Focus. The selector is a simple CSS selector inside the widget. |
| `slots` | no | Areas that hold other widgets (columns, a section's content). The render gets them as `slots.<name>`. |
| `structure` | no | A layout container: when empty, it offers structures (columns, grids) of copies of itself. |
| `constraints.maxPerPage` | no | E.g. one site header per page. |
| `insertLevel`, field `level` | no | Role needed to insert the widget or change a field (`editor` or `designer`). Enforced on save. |
| `requires` | no | A site capability the widget needs (`htmlWidget`). With the capability off, the widget is hidden and refused. |
| `needsContext` | no | The render reads `$ctx`: site, page, pages, menus, dynamic data. |
| `needsHeadings` | no | The render gets `$headings`: the page's headings from every widget's `seo.heading` (a table of contents written on the server). Plain data, safe to pass to a client component. |
| `seo` | no | The headings the widget renders and its FAQ items, for the SEO checks (one H1, heading order), the table of contents and FAQPage JSON-LD. See [Headings](#headings). |
| `validate(props)` | no | Checks beyond the fields. Return messages; the editor shows them and publishing refuses the page. |
| `migrations` | no | `{ [fromVersion]: (props) => nextProps }` for every version below the current one. Stored pages, templates, drafts and import files are upgraded when they are read. |
| `render(props)` | no | The React component. Leave it out to let the site bind the render with `createRegistry(site, { "acme/Timeline": … })`. The site's render wins over the widget's. |

### Field kinds

| Builder | Kind | Props value | Options |
|---|---|---|---|
| `f.text` | text | `string` | `maxLength`, `inline` (edit on the canvas) |
| `f.textarea` | textarea | `string` | `maxLength`, `inline` |
| `f.richtext` | richtext | structured rich text (paragraphs, headings, lists, links), rendered safely | `maxLength` |
| `f.number` | number | `number` | `min`, `max`, `integer` |
| `f.boolean` | boolean | `boolean` | |
| `f.select` | select | one of `options` | `options` (`as const`), `optionLabels` |
| `f.link` | link | `string` | pages, `#anchors`, `#popup-name`, `tel:`, `mailto:`; `javascript:` is always refused |
| `f.image` | image | `{ src, alt, width?, height?, focal? }` | the media library, with alt text |
| `f.list` | list | array of items | `item` (fields), `min`, `max`, `itemLabel` |
| `f.object` | object | nested props | `fields` |

Every field also takes `label`, `required`, `help` and `level`.

### Headings

Declare every heading the widget renders, so the page checks (one H1, no skipped level), the contrast checks (large text) and the table of contents see them:

```ts
seo: { heading: { level: "titleLevel", defaultLevel: 3, text: "title" } }                // level from a prop
seo: { heading: [{ level: 3, text: "front" }, { level: 3, text: ["back"] }] }             // several; a list of props is skipped when empty
seo: { heading: { list: "items", level: 3, text: "title" } }                              // one per list item
seo: { heading: { level: 2, text: ["before", "words.0.text", "after"] } }                 // joined texts, dotted paths
seo: { heading: { list: "slides", level: 2, text: "heading", contents: false } }          // not in a table of contents (a carousel)
seo: { heading: { richText: "content" } }                                                 // the H2–H4 blocks of formatted text
```

### Styles of a widget

Write a widget's own CSS with `BStyle` from `@builder/react/style`, not a bare `<style>`:

```tsx
import { BStyle } from "@builder/react/style";
const CSS = ":where(.acme-tl){display:grid;gap:1rem}";
render: (p) => <section className="acme-tl"><BStyle css={CSS} />…</section>
```

- On published pages all builder CSS becomes **one stylesheet in `<head>`**, and the same CSS is written once however many copies of the widget a page has.
- In the editor it stays next to the widget (the canvas is an iframe).
- Use low-specificity selectors (`:where(…)`), so the Style tab and Site Settings win.
- A site can keep the old in-place `<style>` elements with `NEXT_PUBLIC_BUILDER_STYLES=inline` at build time.

### Rules

- **Pure data plus a render.** The definition must serialize (`toManifest` drops the render), so CI, the editor and validation can read it without running site code.
- **No HTML from content.** Render props as React children. Never use `dangerouslySetInnerHTML` with content; render rich text with the builder's rich text renderer.
- **Fast on the live site.** Prefer plain HTML and CSS. An interactive widget loads its script lazily; see `lazy-widgets.tsx` in a new site. Do not change the page's size after it opens (render lists and placeholders on the server), and give every control at least a 24 × 24 px target.
- **Accessible.** The demo site's e2e tests run axe (WCAG 2.2 AA) on every page on three devices; a widget must pass them.
- **Tests.** Copy [`timeline.test.mts`](../../../examples/widget-timeline/test/timeline.test.mts): manifest, validation, migration, render.

## 3. Kits

A kit is a set of section and page templates for a kind of site:

```ts
export const plumbingKit = defineKit({ id: "plumbing", name: "Plumbing", templates: [...], pageTemplates: [...] });
```

- **Made in the editor**: Templates › Import / Export › *Export as kit* downloads a `.builder.json`.
- **Shipped as code**: `defineKit(kitFromExport(json))`.
- **Checked**: `checkKit(kit, site)` checks a kit against a site's widgets.

## 4. Export files (`.builder.json`)

- **Contents**: pages, section templates, page templates, Theme Builder templates, Site Settings and kit information, plus the widget versions of the site that made the file.
- **Format**: currently version `2` (`EXPORT_VERSION`).
- **Older files**: upgraded step by step (`EXPORT_MIGRATIONS`).
- **Newer files**: refused with a clear message.
- **Import**: every item is validated against the receiving site, older widgets are upgraded by their migrations, and an item that does not fit is left out and named.

## 5. Versions

See [`docs/versioning.md`](../../../docs/versioning.md) and the [CHANGELOG](../../../CHANGELOG.md):

- the packages follow semver;
- every stored format has a version and migrations;
- widget authors bump `version` with a migration for every stored-props change.
